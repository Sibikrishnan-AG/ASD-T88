function checkBoxCont() {
    var checkBox = document.getElementById("myCheckbox");
    var submitButton = document.getElementById("submitButton"); // Ensure the variable matches the ID

    if (checkBox.checked) {
        submitButton.style.display = "inline"; // Show the button
    } else {
        submitButton.style.display = "none"; // Hide the button
    }
}

// Attach the event listener to the checkbox
document.addEventListener("DOMContentLoaded", function() {
    var checkBox = document.getElementById("myCheckbox");
    var submitButton = document.getElementById("submitButton");

    // Initial check on page load
    checkBoxCont();
    checkBox.addEventListener("change", checkBoxCont);
});
